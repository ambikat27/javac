enum Usage{
	
	TV,HOMEHTEATRE,AC;
}