enum Os{
	
	WINDOWS,LINUX,MAC;
}
